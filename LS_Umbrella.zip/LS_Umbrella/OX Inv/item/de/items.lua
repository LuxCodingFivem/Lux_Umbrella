["umbrella"] = {
		label = "Regenschirm",
		weight = 500,
		stack = false,
		close = true,
		allowArmed = false,
	},
