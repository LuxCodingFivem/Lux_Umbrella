["umbrella"] = {
		label = "Umbrella",
		weight = 500,
		stack = false,
		close = true,
		allowArmed = false,
	},