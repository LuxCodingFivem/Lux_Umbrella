fx_version 'cerulean'
games { 'gta5' }

lua54 'yes'

client_scripts {
	'config.lua',
	'client.lua',
}

server_scripts {
	'config.lua',
	'server.lua',
}
